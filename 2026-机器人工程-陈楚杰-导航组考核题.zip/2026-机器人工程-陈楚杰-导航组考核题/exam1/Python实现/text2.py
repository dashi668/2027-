"""
题目：
定义一个结构体 Student，包含：
  - name（字符数组，长度50）
  - id（整数）
  - score（浮点数）

  编写两个函数：
  - input（）：通过指针接收结构体，从键盘输入学生信息
  - display（）：通过指针接收结构体，输出学生信息
  - 要使用 -> 运算符输入和输出

  在 main（） 中：
  - 动态创建一个 Student 结构体变量
  - 调用 input（） 输入数据
  - 调用  display（）输出数据
"""
class Student():
    name = ""
    id = 0
    score = 0.0

    def input_(self):
        self.name = input("请输入姓名：")
        self.id = int(input("请输入学号："))
        self.score = float(input("请输入成绩："))

    def display(self):
        print(f"姓名：{self.name}")
        print(f"学号：{self.id}")
        print(f"成绩：{self.score}")

s1 = Student()
s1.input_()
s1.display()