# 题目：设计一份代码，输入为5、8、2、10、7、15、13、11、20、18
# 利用所学知识将以上输入以升序输出（即以小到大的顺序）

# 1.输入数字并组成列表
num = 0
numList = []
for i in range(10):
    num = int(input("请输入数字："))
    numList.append(num)

# 2.排序
for i in range(9):
    for i in range(9):
        if numList[i] > numList[i+1]:
            t = numList[i+1]
            numList[i+1] = numList[i]
            numList[i] = t

# 3.升序输出该组数字
print(f"升序输出该组数字：{numList}")