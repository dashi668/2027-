"""
题目：
定义一个 Car 类，包含：
- 私有成员：
  - color（string）
  - number（int）

- 公有成员函数：
  - 构造函数：初始化车辆颜色、车牌号信息
  - 析构函数
  - display（）：输出车辆信息

在 main（） 中：
  - 创建 2 个车辆对象
  - 输出车辆信息
"""

class Car():
    color = ""
    number = 0

    def Car(self):
        print("初始化车辆颜色")
        self.color = "white"
        print("初始化车牌号")
        self.number = 88888
        print("-----------------")

    def display(self):
        print(f"车辆颜色：{self.color}")
        print(f"车牌号：{self.number}")
        print("-----------------")

c1 = Car()
c2 = Car()

c1.Car()
c2.Car()

c1.display()
c2.display()